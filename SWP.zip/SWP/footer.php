
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: lightgray;
   color: black;
   text-align: center;
}
</style>
</head>
<body>

<div class="footer">
  <p>Contact Us<br>
  please contact us now on: Tel. 01061332627<br>
   email<a href="m.me/Dermacure.skinlaser"> m.me/Dermacure.skinlaser</a>
  </p>
</div>
</body>
</html> 
