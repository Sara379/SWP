
<html>

<head>

<title>Rooms</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta content="text/html; charset=iso-8859-2" http-equiv="Content-Type">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">




<<div class="w3-top">
  <div class="w3-bar w3-white w3-card" id="myNavbar">
    <a href="clinic.php" class="w3-bar-item w3-button w3-wide">Derma Clinic</a>
    <div class="w3-right w3-hide-small">
    <a href="afterp.php" class="w3-bar-item w3-button"><i class="fa fa-th"></i> Prescription</a>
    <a href="room.php" class="w3-bar-item w3-button"><i class="fa fa-th"></i> Room</a>

      <a href="ContactUs.php" class="w3-bar-item w3-button"><i class="fa fa-envelope"></i> Logout</a>
    </div>


            </a>
        </div>
    </div>
<br>

<style>
.mySlides {display:none;}
.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: lightgray;
   color: black;
   text-align: center;
}
</style>
</head>

<body>

<div class="footer">
  <p>Rooms <br>
  please contact us now on: Tel. 01061332627<br>
   email<a href="m.me/Dermacure.skinlaser"> m.me/Dermacure.skinlaser</a>
  </p>
</div>


<div class="w3-content w3-section" style="max-width:500px">
  <img class="mySlides" src="111.jpg" style="width:100%">
  <img class="mySlides" src="222.jpg" style="width:100%">
  <img class="mySlides" src="333.jpg" style="width:100%">

  
</div>

<script>
var myIndex = 0;
carousel();

function carousel() {
  var i;
  var x = document.getElementsByClassName("mySlides");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";  
  }
  myIndex++;
  if (myIndex > x.length) {myIndex = 1}    
  x[myIndex-1].style.display = "block";  
  setTimeout(carousel, 2000); // Change image every 2 seconds
}
</script>

<div class="w3-display-bottomleft w3-text-grey w3-large" style="padding:24px 48px">
            <i class="fa fa-facebook-official w3-hover-opacity"></i>
            <i class="fa fa-instagram w3-hover-opacity"></i>
            <i class="fa fa-snapchat w3-hover-opacity"></i>
            <i class="fa fa-pinterest-p w3-hover-opacity"></i>
            <i class="fa fa-twitter w3-hover-opacity"></i>
            <i class="fa fa-linkedin w3-hover-opacity"></i>
        </div>
</body>
</html>
